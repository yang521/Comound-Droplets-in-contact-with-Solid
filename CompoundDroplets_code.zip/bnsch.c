/************************************************

   Binary NSCH
   with variable density and variable viscosity

************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "util.h"
#include "bnsch.h"
#define NR_END 1
#define max(a,b) (a>b?a:b)

int nx, ny, n_level,  c_relax, count;
double pi, xleft, xright, yleft, yright, h, dt, gam, Cahn,  **co, **Mo, kkk,Pe,
        **worku, **workv, **workp, SS, **mc, **ctt, **nctt, **octt, **ocff, **cff, **ncff,
       **ct, **sc, **smu, **mu, **pss, **H1, **H2, **H3, **H4, **beta, theta1, theta2,
       theta3, **intoc, **intct, **intcf, theta13, theta23, theta12, theta21;
       
       
       //where cff is c3, ctt is c2; co is c0!!!
       
char bufferc[100],bufferc0[100],bufferc2[100], bufferc3[100];
int main()
{
    extern int nx, ny, n_level,  c_relax, count;
    extern double pi, xleft, xright, yleft, yright, h, dt, gam, Cahn,  **co, **Mo, kkk,Pe,
                  **worku, **workv, **workp, SS, **mc, **ctt, **nctt, **octt, **ocff, **cff, **ncff,
                  **ct, **sc, **smu, **mu, **pss, **H1, **H2, **H3, **H4, **beta, theta1, theta2,
                 theta3, **intoc, **intct, **intcf, theta13, theta23, theta12, theta21;

    extern char  bufferc[100],bufferc0[100],bufferc2[100], bufferc3[100];
    int i,j, it, max_it, ns;
    double **oc, **ooc, **nc;
    
    FILE  *fc, *fc0, *fc2, *fc3, *mycpu;
    
    clock_t start, end;
    double elapsed;
    
    
    /*****/
     
    nx = gnx;
    ny = gny;
    n_level = (int)(log(nx)/log(2)-0.9);
    
    c_relax = 5;
    
    pi = 4.0*atan(1.0);
    
    xleft = 0.0, xright = 4.0;
    yleft = 0.0, yright = 2.0;
    
    count = 0;
    
    /***********************/
    
    h = (xright-xleft)/(double)nx;


   dt = 0.5*h;
   
   dt = 0.1;
   
    gam = 10.0*h/(4.0*sqrt(2.0)*atanh(0.9));

    Cahn = pow(gam,2);
    
    max_it = 5000;
    ns = max_it/50;
   
    SS = 2.0;
    
    Pe = 1.0;

    theta13 = pi/2.0;

    theta23 = 60.0*pi/180.0;

    theta12 = 120.0*pi/180.0;

    theta21 = pi-theta12;

    /***********************/
    
    printf("nx = %d, ny = %d\n", nx, ny);
    printf("n_level = %d\n", n_level);
    printf("dt      = %f\n", dt);
    printf("max_it  = %d\n", max_it);
    printf("ns      = %d\n", ns);

    intoc = dmatrix(0, nx+1, 0, ny+1);
    intct = dmatrix(0, nx+1, 0, ny+1);
    intcf = dmatrix(0, nx+1, 0, ny+1);
  
    Mo = dmatrix(0, nx+1, 0, ny+1);
    pss = dmatrix(1, nx, 1, ny);
    co = dmatrix(0, nx+1, 0, ny+1);
    ctt = dmatrix(0, nx+1, 0, ny+1);
    nctt = dmatrix(0, nx+1, 0, ny+1);
    octt = dmatrix(0, nx+1, 0, ny+1);

    cff = dmatrix(0, nx+1, 0, ny+1);
    ncff = dmatrix(0, nx+1, 0, ny+1);
    ocff = dmatrix(0, nx+1, 0, ny+1);

    ooc = dmatrix(0, nx+1, 0, ny+1);
    oc = dmatrix(0, nx+1, 0, ny+1);
    nc = dmatrix(0, nx+1, 0, ny+1);

    beta = dmatrix(0, nx+1, 0, ny+1);


    H1 = dmatrix(0, nx+1, 0, ny+1);
    H2 = dmatrix(0, nx+1, 0, ny+1);
    H3 = dmatrix(0, nx+1, 0, ny+1);
    H4 = dmatrix(0, nx+1, 0, ny+1);
  
    worku = dmatrix(0, nx, 1, ny);
    workv = dmatrix(1, nx, 0, ny);
    workp = dmatrix(1, nx, 1, ny);
   
    ct = dmatrix(1, nx, 1, ny);
    sc = dmatrix(1, nx, 1, ny);
    smu = dmatrix(1, nx, 1, ny);
    mu = dmatrix(1, nx, 1, ny);
    
    zero_matrix(mu, 1, nx, 1, ny); 

   
    sprintf(bufferc,"data1/datac.m");
    sprintf(bufferc0,"data1/datac0.m");
    sprintf(bufferc2,"data1/datac2.m");
    sprintf(bufferc3,"data1/datac3.m");
   
    fc = fopen(bufferc,"w");
    fc0 = fopen(bufferc0,"w");
    fc2 = fopen(bufferc2,"w");
    fc3 = fopen(bufferc3,"w");
  
    fclose(fc);
    fclose(fc0);
    fclose(fc2);
    fclose(fc3);
    
    initialization(oc,co,ctt,cff);
    

   ijloop{  Mo[i][j] = 1.0-co[i][j]; }

    augmenc(co, nx, ny);
    augmenc(Mo, nx, ny);
    

    mat_copy(nc, oc, 1, nx, 1, ny);

    mat_copy(ooc, oc, 1, nx, 1, ny);

    mat_copy(octt, ctt, 1, nx, 1, ny);

   mat_copy(ocff, cff, 1, nx, 1, ny);
    
    print_data(nc,co,ctt,cff);
    
    
    mycpu = fopen("data1/cpu.m","w");
  
     start = clock();
    
  
    for (it=1; it<=1; it++) {
      

     
    ijloop{
    
        theta1 = cff[i][j]*theta13/(cff[i][j]+ctt[i][j]+1.0e-10) + ctt[i][j]*theta12/(cff[i][j] + ctt[i][j]+1.0e-10);

        theta2 = cff[i][j]*theta23/(cff[i][j]+oc[i][j]+1.0e-10) + oc[i][j]*theta21/(cff[i][j] + oc[i][j]+1.0e-10);

        theta3 = oc[i][j]*theta1/(ctt[i][j]+oc[i][j]+1.0e-10) + ctt[i][j]*theta2/(ctt[i][j] + oc[i][j]+1.0e-10);

        
      H1[i][j] = (  pow(oc[i][j],3)-(3.0/2)*pow(oc[i][j],2) + 0.5*oc[i][j] 
      + gam*oc[i][j]*(oc[i][j]-1.0)*sqrt(pow(co[i+1][j]-co[i-1][j],2)/(4.0*h*h) 
      + pow(co[i][j+1]-co[i][j-1],2)/(4.0*h*h))*cos(theta1)/sqrt(2.0)  );
      
   
      H2[i][j] = (  pow(ctt[i][j],3)-(3.0/2)*pow(ctt[i][j],2) + 0.5*ctt[i][j] 
      + gam*ctt[i][j]*(ctt[i][j]-1.0)*sqrt(pow(co[i+1][j]-co[i-1][j],2)/(4.0*h*h) 
      + pow(co[i][j+1]-co[i][j-1],2)/(4.0*h*h))*cos(theta2)/sqrt(2.0)  );

 
      H3[i][j] = (  pow(cff[i][j],3)-(3.0/2)*pow(cff[i][j],2) + 0.5*cff[i][j] 
      + gam*cff[i][j]*(cff[i][j]-1.0)*sqrt(pow(co[i+1][j]-co[i-1][j],2)/(4.0*h*h) 
      + pow(co[i][j+1]-co[i][j-1],2)/(4.0*h*h))*cos(pi-theta3)/sqrt(2.0)  );
      
      
      H4[i][j] = pow(co[i][j],3)-(3.0/2)*pow(co[i][j],2) + 0.5*co[i][j];

                  
       beta[i][j] =   -(1.0/4)*(  H1[i][j] + H2[i][j] + H3[i][j] + H4[i][j] );

       }
        

          inicahn1(oc, Mo, H1, beta, nc);

          inicahn1(ctt, Mo, H2, beta, nctt);

          inicahn1(cff, Mo, H3, beta, ncff);
      
  /*  ijloop{
        
        ncff[i][j] = 1.0-co[i][j]-nc[i][j]-nctt[i][j];
        
        }*/

        mat_copy(oc, nc, 1, nx, 1, ny);
        mat_copy(ctt, nctt, 1, nx, 1, ny);
        mat_copy(cff, ncff, 1, nx, 1, ny);
        
        printf("it = %d\n", it);
       

    }


  for (it=2; it<=max_it; it++) {
    
    ijloop{  

     intoc[i][j] = 2.0*oc[i][j] - ooc[i][j];
     intct[i][j] = 2.0*ctt[i][j] - octt[i][j];
     intcf[i][j] = 2.0*cff[i][j] - ocff[i][j];

      }
    
     
    ijloop{
    
   
        theta1 = intcf[i][j]*theta13/(intcf[i][j]+intct[i][j]+1.0e-10) + intct[i][j]*theta12/(intcf[i][j] + intct[i][j]+1.0e-10);

        theta2 = intcf[i][j]*theta23/(intcf[i][j]+intoc[i][j]+1.0e-10) + intoc[i][j]*theta21/(intcf[i][j] + intoc[i][j]+1.0e-10);

        theta3 = intoc[i][j]*theta1/(intct[i][j]+intoc[i][j]+1.0e-10) + intct[i][j]*theta2/(intct[i][j] + intoc[i][j]+1.0e-10);


      H1[i][j] = (  pow(intoc[i][j],3)-(3.0/2)*pow(intoc[i][j],2) + 0.5*intoc[i][j] 
      + gam*intoc[i][j]*(intoc[i][j]-1.0)*sqrt(pow(co[i+1][j]-co[i-1][j],2)/(4.0*h*h) 
      + pow(co[i][j+1]-co[i][j-1],2)/(4.0*h*h))*cos(theta1)/sqrt(2.0)  );

      H2[i][j] = (  pow(intct[i][j],3)-(3.0/2)*pow(intct[i][j],2) + 0.5*intct[i][j] 
      + gam*intct[i][j]*(intct[i][j]-1.0)*sqrt(pow(co[i+1][j]-co[i-1][j],2)/(4.0*h*h) 
      + pow(co[i][j+1]-co[i][j-1],2)/(4.0*h*h))*cos(theta2)/sqrt(2.0)  );

 
      H3[i][j] = (  pow(intcf[i][j],3)-(3.0/2)*pow(intcf[i][j],2) + 0.5*intcf[i][j] 
      + gam*intcf[i][j]*(intcf[i][j]-1.0)*sqrt(pow(co[i+1][j]-co[i-1][j],2)/(4.0*h*h) 
      + pow(co[i][j+1]-co[i][j-1],2)/(4.0*h*h))*cos(pi-theta3)/sqrt(2.0)  );
      
      
      H4[i][j] = pow(co[i][j],3)-(3.0/2)*pow(co[i][j],2) + 0.5*co[i][j];

                  
        beta[i][j] =   -(1.0/4)*(  H1[i][j] + H2[i][j] + H3[i][j] + H4[i][j] );

       }
      
     
          cahn1(oc, ooc, Mo, H1, beta, nc);

          cahn1(ctt, octt, Mo, H2, beta, nctt);

          cahn1(cff, ocff, Mo, H3, beta, ncff);
        
      /*  ijloop{
        
        ncff[i][j] = 1.0-co[i][j]-nc[i][j]-nctt[i][j];
        
        }*/
    

        mat_copy(ooc, oc, 1, nx, 1, ny);
        mat_copy(octt, ctt, 1, nx, 1, ny);
        mat_copy(ocff, cff, 1, nx, 1, ny);
        mat_copy(oc, nc, 1, nx, 1, ny);
        mat_copy(ctt, nctt, 1, nx, 1, ny);
        mat_copy(cff, ncff, 1, nx, 1, ny);
        
        printf("it = %d\n", it);
        
        
  
        if (it % ns == 0) {
            count++;
           print_data(nc,co,nctt,ncff);

            printf("print out counts %d\n", count);
            
            end = clock();
           elapsed = ((float) (end - start)) / CLOCKS_PER_SEC;
      
        fprintf(mycpu, "%f \n", elapsed);
            
            
        }
    }
    
      fclose(mycpu); 
    
    return 0;
}

void initialization(double **c, double **co, double **ctt, double **cff)
{
    extern double xright, yright, h, gam, **psi, pi, kkk, alphaa;
    
    int i, j;
    double x, y, x2, y2, ka;

     ka = 10.0;
    
    ijloop {
    
      //  x = ((double)i-0.5)*h;
       // y = ((double)j-0.5)*h;
        
        x = xleft + ((double)i-0.5)*h;
        y = yleft + ((double)j-0.5)*h;
        

         
         co[i][j] = 0.5 + 0.5*tanh( -(y - 0.15 - 0.0*cos(12.0*pi*x) )/(0.504*sqrt(2.0)*gam) );
         
         


 //  co[i][j] = 0.5+0.5*tanh((-max(fabs(x-0.75)-0.75, fabs(y-0.5)-((1.0/6.0)*x-0.01)))/(sqrt(2.0)*gam));


    //  c[i][j] = (1.0-co[i][j])*( 0.5 + 0.5*tanh( (0.15 - sqrt(pow(x-0.7,2)+pow(y-0.5,2)) )/(1.0*sqrt(2.0)*gam) ) 
    //  + 0.5 + 0.5*tanh( -(fabs(x-0.24)-0.1)/(1.0*sqrt(2.0)*gam) ) );
     
   c[i][j] = 0.0;
 
  if( x < 2.0){
   c[i][j] = (1.0-co[i][j])*(0.5+0.5*tanh((1.0 - sqrt(pow(x-2.0,2)+pow(y-0.15,2)) )/(0.504*sqrt(2.0)*gam)));

    }


   ctt[i][j] = (1.0-co[i][j]-c[i][j])*(0.5+0.5*tanh((1.0 - sqrt(pow(x-2.0,2)+pow(y-0.15,2)) )/(0.504*sqrt(2.0)*gam)));
   
   
 /*  if( x< 2.0 && sqrt(pow(x-2.0,2)+pow(y-0.15,2)) < 1.0){
   c[i][j] = (1.0-co[i][j])*1.0;
   ctt[i][j] = 0.0;
   }
   else if( x> 2.0 && sqrt(pow(x-2.0,2)+pow(y-0.15,2)) < 1.0){
   ctt[i][j] = (1.0-co[i][j])*1.0;
   c[i][j] = 0.0;
   }
   else{
   ctt[i][j] = 0.0;
   c[i][j] = 0.0;
   }*/
   
  
   
 //  c[i][j] = (1.0-co[i][j])*(0.5+0.5*tanh((-max(fabs(x-0.75)-0.3, fabs(y-0.5)-0.28))/(sqrt(2.0)*gam)));

 //  if( y < 0.5 )
//  c[i][j] = 0.0;


  /*   if( co[i][j] + pss[i][j] > 1.0){
     c[i][j] = 1.0 - co[i][j]; }
     else{
     c[i][j] = pss[i][j];
     } */


     cff[i][j] = 1.0 - c[i][j] - ctt[i][j] - co[i][j];
        
    }
 
     
}



void augmenc(double **c, int nxt, int nyt)
{
    int i, j;
    
    for (j=1; j<=nyt; j++) { 
        c[0][j] = c[nxt][j];
        c[nxt+1][j] = c[1][j];
    }
    
    for (i=0; i<=nxt+1; i++) { 
        c[i][0] = c[i][1];
        c[i][nyt+1] = c[i][nyt];
    }
    
}


void cahn1(double **c_old, double **cc_old, double **Mo, double **H, double **beta, double **c_new)
{
    extern int nx, ny;
    extern double **ct, **sc, **smu, **mu;
    
    int it_mg = 1, max_it_CH = 500;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, c_old, 1, nx, 1, ny);
    
    source1(c_old, cc_old, H, beta, sc, smu);
    
    while (it_mg <= max_it_CH && resid > tol) {
        
        vcycle(c_new, Mo, mu, sc, smu, nx ,ny, 1);

        resid = error(ct, c_new, nx, ny);
        mat_copy(ct, c_new, 1, nx, 1, ny);
        
        it_mg++;
    }
    printf("cahn1 %16.14f   %d\n", resid, it_mg-1);
}




void source1(double **c_old, double **cc_old, double **H, double **beta, double **src_c, double **src_mu)
{
    extern int nx, ny;
    extern double dt, SS, Cahn, **ctt, **co, **ooc;
    
    int i, j;

    ijloop {
        src_c[i][j] = (4.0*c_old[i][j]-cc_old[i][j])/(2.0*dt);
        
        src_mu[i][j] = H[i][j] + beta[i][j] -SS*( 2.0*c_old[i][j] - cc_old[i][j] );
    }

       
}



void inicahn1(double **c_old, double **Mo, double **H, double **beta, double **c_new)
{
    extern int nx, ny;
    extern double **ct, **sc, **smu, **mu;
    
    int it_mg = 1, max_it_CH = 500;
    double resid = 1.0, tol = 1.0e-6;
    
    mat_copy(ct, c_old, 1, nx, 1, ny);
    
    inisource1(c_old, H, beta, sc, smu);
    
    while (it_mg <= max_it_CH && resid > tol) {
        
        inivcycle(c_new, Mo, mu, sc, smu, nx ,ny, 1);

        resid = error(ct, c_new, nx, ny);
        mat_copy(ct, c_new, 1, nx, 1, ny);
        
        it_mg++;
    }
    printf("cahn1 %16.14f   %d\n", resid, it_mg-1);
}



void inisource1(double **c_old, double **H, double **beta, double **src_c, double **src_mu)
{
    extern int nx, ny;
    extern double dt, SS, Cahn, **ctt, **co, **ooc;
    
    int i, j;

    ijloop {
        src_c[i][j] = c_old[i][j]/dt;
        
        src_mu[i][j] = H[i][j] + beta[i][j] -SS*c_old[i][j];
    }

       
}


void laplace_ch(double **Mo, double **a, double **lap_a, int nxt, int nyt)
{
    extern double xright, xleft;
    
    int i, j;
    double ht2, dadx_L, dadx_R, dady_B, dady_T;
    
    ht2 = pow((xright-xleft)/(double)nxt,2);
    
    ijloopt {
        
        if (i > 1)
            dadx_L = 0.5*(Mo[i][j]+Mo[i-1][j])*( a[i][j] - a[i-1][j] );
        else
            dadx_L = 0.5*(Mo[i][j]+Mo[nxt][j])*( a[i][j] - a[nxt][j] );
        
        if (i < nxt)
            dadx_R = 0.5*(Mo[i+1][j]+Mo[i][j])*( a[i+1][j] - a[i][j] );
        else
            dadx_R = 0.5*(Mo[1][j]+Mo[i][j])*( a[1][j] - a[i][j] );
            
            
        
       if (j > 1)
            dady_B = 0.5*(Mo[i][j]+Mo[i][j-1])*( a[i][j] - a[i][j-1] );
        else
            dady_B = 0.0; //0.5*(Mo[i][j]+Mo[i][nyt])*( a[i][j] - a[i][nyt] );
        
        if (j < nyt)
            dady_T = 0.5*(Mo[i][j+1]+Mo[i][j])*( a[i][j+1] - a[i][j] );
        else
            dady_T = 0.0; //0.5*(Mo[i][1]+Mo[i][j])*( a[i][1] - a[i][j] );
            
            
        
        lap_a[i][j] = (dadx_R - dadx_L + dady_T - dady_B)/ht2;
    }
    
}



void vcycle(double **uf_new, double **Mo, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    relax(uf_new, Mo, wf_new, su, sw, ilevel, nxf, nyf);
    
  if (ilevel < n_level) {
        
        int nxc, nyc;
        double **uc_new, **wc_new, **duc, **dwc, 
               **oMo,
               **uc_def, **wc_def, **uf_def, **wf_def;
        
        nxc = nxf/2, nyc = nyf/2;
        
        uc_new = dmatrix(1, nxc, 1, nyc);
        wc_new = dmatrix(1, nxc, 1, nyc);
        duc = dmatrix(1, nxc, 1, nyc);
        dwc = dmatrix(1, nxc, 1, nyc);

         oMo = dmatrix(0, nxc+1, 0, nyc+1);
        

        uc_def = dmatrix(1, nxc, 1, nyc);
        wc_def = dmatrix(1, nxc, 1, nyc);
        uf_def = dmatrix(1, nxf, 1, nyf);
        wf_def = dmatrix(1, nxf, 1, nyf);
       

        defect(duc, dwc, Mo, uf_new, wf_new, su, sw, nxf, nyf);
        

        restrict1(Mo, oMo, nxc, nyc);
    
        
        augmenc(oMo, nxc, nyc);
             
          zero_matrix(uc_def, 1, nxc, 1, nyc);
          zero_matrix(wc_def, 1, nxc, 1, nyc);
        
        vcycle(uc_def, oMo, wc_def, duc, dwc, nxc, nyc, ilevel+1);
        
        prolong_ch(uc_def, uf_def, wc_def, wf_def, nxc, nyc);
        
        mat_add2(uf_new, uf_new, uf_def, wf_new, wf_new, wf_def, 1, nxf, 1, nyf);
        
        relax(uf_new, Mo, wf_new, su, sw, ilevel, nxf, nyf);
        
        free_dmatrix(uc_new, 1, nxc, 1, nyc);
        free_dmatrix(wc_new, 1, nxc, 1, nyc);
        free_dmatrix(duc, 1, nxc, 1, nyc);
        free_dmatrix(dwc, 1, nxc, 1, nyc);

        free_dmatrix(oMo, 0, nxc+1, 0, nyc+1);
     

        free_dmatrix(uc_def, 1, nxc, 1, nyc);
        free_dmatrix(wc_def, 1, nxc, 1, nyc);
        free_dmatrix(uf_def, 1, nxf, 1, nyf);
        free_dmatrix(wf_def, 1, nxf, 1, nyf);
    }

}


void inivcycle(double **uf_new, double **Mo, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel)
{
    extern int n_level;
    
    inirelax(uf_new, Mo, wf_new, su, sw, ilevel, nxf, nyf);
    
  if (ilevel < n_level) {
        
        int nxc, nyc;
        double **uc_new, **wc_new, **duc, **dwc, 
               **oMo,
               **uc_def, **wc_def, **uf_def, **wf_def;
        
        nxc = nxf/2, nyc = nyf/2;
        
        uc_new = dmatrix(1, nxc, 1, nyc);
        wc_new = dmatrix(1, nxc, 1, nyc);
        duc = dmatrix(1, nxc, 1, nyc);
        dwc = dmatrix(1, nxc, 1, nyc);

         oMo = dmatrix(0, nxc+1, 0, nyc+1);
        

        uc_def = dmatrix(1, nxc, 1, nyc);
        wc_def = dmatrix(1, nxc, 1, nyc);
        uf_def = dmatrix(1, nxf, 1, nyf);
        wf_def = dmatrix(1, nxf, 1, nyf);
        
  

        inidefect(duc, dwc, Mo, uf_new, wf_new, su, sw, nxf, nyf);
        

        restrict1(Mo, oMo, nxc, nyc);
    
        
        augmenc(oMo, nxc, nyc);
             
          zero_matrix(uc_def, 1, nxc, 1, nyc);
          zero_matrix(wc_def, 1, nxc, 1, nyc);
        
        inivcycle(uc_def, oMo, wc_def, duc, dwc, nxc, nyc, ilevel+1);
        
        prolong_ch(uc_def, uf_def, wc_def, wf_def, nxc, nyc);
        
        mat_add2(uf_new, uf_new, uf_def, wf_new, wf_new, wf_def, 1, nxf, 1, nyf);
        
        inirelax(uf_new, Mo, wf_new, su, sw, ilevel, nxf, nyf);
        
        free_dmatrix(uc_new, 1, nxc, 1, nyc);
        free_dmatrix(wc_new, 1, nxc, 1, nyc);
        free_dmatrix(duc, 1, nxc, 1, nyc);
        free_dmatrix(dwc, 1, nxc, 1, nyc);

        free_dmatrix(oMo, 0, nxc+1, 0, nyc+1);
     

        free_dmatrix(uc_def, 1, nxc, 1, nyc);
        free_dmatrix(wc_def, 1, nxc, 1, nyc);
        free_dmatrix(uf_def, 1, nxf, 1, nyf);
        free_dmatrix(wf_def, 1, nxf, 1, nyf);
    }

}

void relax(double **c_new, double **Mo, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt)
{
    extern int c_relax;
    extern double xright, xleft,dt, Cahn, gam, SS, Pe;
    
    int i, j, iter;
    double ht2, a[4], f[2], det, x_fac, y_fac;
    
    ht2 = pow((xright-xleft)/(double)nxt,2);
    
    for (iter=1; iter<=c_relax; iter++) {
        
        ijloopt {

        if (i==1) 
   	       x_fac = 0.5*(Mo[i+1][j]+Mo[i][j])+0.5*(Mo[i][j]+Mo[nxt][j]);
        else if (i==nxt) 
	       x_fac = 0.5*(Mo[1][j]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i-1][j]);
        else
	       x_fac = 0.5*(Mo[i+1][j]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i-1][j]);


             if (j==1) 
   	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j]);
            else if (j==nyt) 
	       y_fac = 0.5*(Mo[i][j]+Mo[i][j-1]);
            else
	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][j-1]);
           
       /*  if (j==1) 
   	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][nyt]);
        else if (j==nyt) 
	       y_fac = 0.5*(Mo[i][1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][j-1]);
        else
	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][j-1]);*/
 


            a[0] = 3.0/(2.0*dt);
            
            a[1] = (x_fac+y_fac)/(Pe*ht2);
            
           /* a[1] = 2.0/ht2;
            if (j > 1)   a[1] += 1.0/(ht2);
            if (j < nyt) a[1] += 1.0/(ht2);*/
         
             
            a[2] =  -SS - Cahn*(x_fac+y_fac)/ht2;
           
          /* a[2] =  -SS - Cahn*2.0/ht2;
            if (j > 1)   a[2] += -Cahn/ht2;
            if (j < nyt) a[2] += -Cahn/ht2;*/
         
            a[3] = 1.0;
            
            f[0] = su[i][j];


            if (i>1) f[0] +=  0.5*(Mo[i][j]+Mo[i-1][j])*mu_new[i-1][j]/(Pe*ht2);
         
           else 
                       f[0] += 0.5*(Mo[i][j]+Mo[nxt][j])*mu_new[nxt][j]/(Pe*ht2);

           if (i<nxt) f[0] += 0.5*(Mo[i+1][j]+Mo[i][j])*mu_new[i+1][j]/(Pe*ht2);
         
           else 
                        f[0] += 0.5*(Mo[1][j]+Mo[i][j])*mu_new[1][j]/(Pe*ht2);
                        
         //   if (j > 1)   f[0] += mu_new[i][j-1]/(ht2);
         //   if (j < nyt) f[0] += mu_new[i][j+1]/(ht2);


         /*  if (j>1) f[0] +=  0.5*(Mo[i][j]+Mo[i][j-1])*mu_new[i][j-1]/ht2;
         
           else 
                       f[0] += 0.5*(Mo[i][j]+Mo[i][nyt])*mu_new[i][nyt]/ht2;

           if (j<nyt) f[0] += 0.5*(Mo[i][j+1]+Mo[i][j])*mu_new[i][j+1]/ht2;
         
           else 
                        f[0] += 0.5*(Mo[i][1]+Mo[i][j])*mu_new[i][1]/ht2; */
                        
                        
         if( j==1)                
         f[0] +=  0.5*(Mo[i][2]+Mo[i][1])*mu_new[i][2]/(Pe*ht2);
         else if( j==nyt)         
         f[0] +=  0.5*(Mo[i][nyt]+Mo[i][nyt-1])*mu_new[i][nyt-1]/(Pe*ht2);
         else  
         f[0] +=  ( 0.5*(Mo[i][j+1]+Mo[i][j])*mu_new[i][j+1] + 0.5*(Mo[i][j]+Mo[i][j-1])*mu_new[i][j-1] )/(Pe*ht2);
         


            
            f[1] = sw[i][j];
            
              if (i>1) f[1] -=  Cahn*0.5*(Mo[i][j]+Mo[i-1][j])*c_new[i-1][j]/ht2;
         
           else 
                       f[1] -= Cahn*0.5*(Mo[i][j]+Mo[nxt][j])*c_new[nxt][j]/ht2;

           if (i<nxt) f[1] -= Cahn*0.5*(Mo[i+1][j]+Mo[i][j])*c_new[i+1][j]/ht2;
         
           else 
                        f[1] -= Cahn*0.5*(Mo[1][j]+Mo[i][j])*c_new[1][j]/ht2;
                        
                        
         //   if (j > 1)   f[1] -=Cahn*c_new[i][j-1]/ht2;
         //   if (j < nyt) f[1] -= Cahn*c_new[i][j+1]/ht2;          
                        
                        
         /*  if (j>1) f[1] -=  Cahn*0.5*(Mo[i][j]+Mo[i][j-1])*c_new[i][j-1]/ht2;
         
           else 
                       f[1] -= Cahn*0.5*(Mo[i][j]+Mo[i][nyt])*c_new[i][nyt]/ht2;

           if (j<nyt) f[1] -= Cahn*0.5*(Mo[i][j+1]+Mo[i][j])*c_new[i][j+1]/ht2;
         
           else 
                        f[1] -= Cahn*0.5*(Mo[i][1]+Mo[i][j])*c_new[i][1]/ht2; */
                        
                        
         if( j==1)                
         f[1] -=  Cahn*0.5*(Mo[i][2]+Mo[i][1])*c_new[i][2]/ht2;
         else if( j==nyt)         
         f[1] -=  Cahn*0.5*(Mo[i][nyt]+Mo[i][nyt-1])*c_new[i][nyt-1]/ht2;
         else  
         f[1] -=  Cahn*( 0.5*(Mo[i][j+1]+Mo[i][j])*c_new[i][j+1] + 0.5*(Mo[i][j]+Mo[i][j-1])*c_new[i][j-1] )/ht2;          

 
            
            det = a[0]*a[3] - a[1]*a[2];
            
            c_new[i][j] = (a[3]*f[0] - a[1]*f[1])/det;
            mu_new[i][j] = (-a[2]*f[0] + a[0]*f[1])/det;
        }
    }
    
}



void inirelax(double **c_new, double **Mo, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt)
{
    extern int c_relax;
    extern double xright, xleft,dt, Cahn, gam, SS, Pe;
    
    int i, j, iter;
    double ht2, a[4], f[2], det, x_fac, y_fac;
    
    ht2 = pow((xright-xleft)/(double)nxt,2);
    
    for (iter=1; iter<=c_relax; iter++) {
        
        ijloopt {

        if (i==1) 
   	       x_fac = 0.5*(Mo[i+1][j]+Mo[i][j])+0.5*(Mo[i][j]+Mo[nxt][j]);
        else if (i==nxt) 
	       x_fac = 0.5*(Mo[1][j]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i-1][j]);
        else
	       x_fac = 0.5*(Mo[i+1][j]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i-1][j]);


             if (j==1) 
   	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j]);
            else if (j==nyt) 
	       y_fac = 0.5*(Mo[i][j]+Mo[i][j-1]);
            else
	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][j-1]);
           
       /*  if (j==1) 
   	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][nyt]);
        else if (j==nyt) 
	       y_fac = 0.5*(Mo[i][1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][j-1]);
        else
	       y_fac = 0.5*(Mo[i][j+1]+Mo[i][j])+0.5*(Mo[i][j]+Mo[i][j-1]);*/
 


            a[0] = 1.0/dt;
            
            a[1] = (x_fac+y_fac)/(Pe*ht2);
            
           /* a[1] = 2.0/ht2;
            if (j > 1)   a[1] += 1.0/(ht2);
            if (j < nyt) a[1] += 1.0/(ht2);*/
         
             
            a[2] =  -SS - Cahn*(x_fac+y_fac)/ht2;
           
          /* a[2] =  -SS - Cahn*2.0/ht2;
            if (j > 1)   a[2] += -Cahn/ht2;
            if (j < nyt) a[2] += -Cahn/ht2;*/
         
            a[3] = 1.0;
            
            f[0] = su[i][j];


            if (i>1) f[0] +=  0.5*(Mo[i][j]+Mo[i-1][j])*mu_new[i-1][j]/(Pe*ht2);
         
           else 
                       f[0] += 0.5*(Mo[i][j]+Mo[nxt][j])*mu_new[nxt][j]/(Pe*ht2);

           if (i<nxt) f[0] += 0.5*(Mo[i+1][j]+Mo[i][j])*mu_new[i+1][j]/(Pe*ht2);
         
           else 
                        f[0] += 0.5*(Mo[1][j]+Mo[i][j])*mu_new[1][j]/(Pe*ht2);
                        
         //   if (j > 1)   f[0] += mu_new[i][j-1]/(ht2);
         //   if (j < nyt) f[0] += mu_new[i][j+1]/(ht2);


         /*  if (j>1) f[0] +=  0.5*(Mo[i][j]+Mo[i][j-1])*mu_new[i][j-1]/ht2;
         
           else 
                       f[0] += 0.5*(Mo[i][j]+Mo[i][nyt])*mu_new[i][nyt]/ht2;

           if (j<nyt) f[0] += 0.5*(Mo[i][j+1]+Mo[i][j])*mu_new[i][j+1]/ht2;
         
           else 
                        f[0] += 0.5*(Mo[i][1]+Mo[i][j])*mu_new[i][1]/ht2; */
                        
                        
         if( j==1)                
         f[0] +=  0.5*(Mo[i][2]+Mo[i][1])*mu_new[i][2]/ht2;
         else if( j==nyt)         
         f[0] +=  0.5*(Mo[i][nyt]+Mo[i][nyt-1])*mu_new[i][nyt-1]/ht2;
         else  
         f[0] +=  ( 0.5*(Mo[i][j+1]+Mo[i][j])*mu_new[i][j+1] + 0.5*(Mo[i][j]+Mo[i][j-1])*mu_new[i][j-1] )/ht2;
         


            
            f[1] = sw[i][j];
            
              if (i>1) f[1] -=  Cahn*0.5*(Mo[i][j]+Mo[i-1][j])*c_new[i-1][j]/ht2;
         
           else 
                       f[1] -= Cahn*0.5*(Mo[i][j]+Mo[nxt][j])*c_new[nxt][j]/ht2;

           if (i<nxt) f[1] -= Cahn*0.5*(Mo[i+1][j]+Mo[i][j])*c_new[i+1][j]/ht2;
         
           else 
                        f[1] -= Cahn*0.5*(Mo[1][j]+Mo[i][j])*c_new[1][j]/ht2;
                        
                        
         //   if (j > 1)   f[1] -=Cahn*c_new[i][j-1]/ht2;
         //   if (j < nyt) f[1] -= Cahn*c_new[i][j+1]/ht2;          
                        
                        
         /*  if (j>1) f[1] -=  Cahn*0.5*(Mo[i][j]+Mo[i][j-1])*c_new[i][j-1]/ht2;
         
           else 
                       f[1] -= Cahn*0.5*(Mo[i][j]+Mo[i][nyt])*c_new[i][nyt]/ht2;

           if (j<nyt) f[1] -= Cahn*0.5*(Mo[i][j+1]+Mo[i][j])*c_new[i][j+1]/ht2;
         
           else 
                        f[1] -= Cahn*0.5*(Mo[i][1]+Mo[i][j])*c_new[i][1]/ht2; */
                        
                        
         if( j==1)                
         f[1] -=  Cahn*0.5*(Mo[i][2]+Mo[i][1])*c_new[i][2]/(Pe*ht2);
         else if( j==nyt)         
         f[1] -=  Cahn*0.5*(Mo[i][nyt]+Mo[i][nyt-1])*c_new[i][nyt-1]/(Pe*ht2);
         else  
         f[1] -=  Cahn*( 0.5*(Mo[i][j+1]+Mo[i][j])*c_new[i][j+1] + 0.5*(Mo[i][j]+Mo[i][j-1])*c_new[i][j-1] )/(Pe*ht2);          

 
            
            det = a[0]*a[3] - a[1]*a[2];
            
            c_new[i][j] = (a[3]*f[0] - a[1]*f[1])/det;
            mu_new[i][j] = (-a[2]*f[0] + a[0]*f[1])/det;
        }
    }
    
}


void defect(double **duc, double **dwc, double **Mo, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf)
{
    double **ruf, **rwf, **ruc, **rwc, **rruf, **rrwf;
    
    ruf = dmatrix(1, nxf, 1, nyf);
    rwf = dmatrix(1, nxf, 1, nyf);
    rruf = dmatrix(1, nxf/2, 1, nyf/2);
    rrwf = dmatrix(1, nxf/2, 1, nyf/2);
    
    
    
    nonL(ruf, rwf, Mo, uf_new, wf_new, nxf, nyf);
    
 

    mat_sub2(ruf, suf, ruf, rwf, swf, rwf, 1, nxf, 1, nyf);
    

    restrict2(ruf, duc, rwf, dwc, nxf/2, nyf/2);
    
   
    free_dmatrix(ruf, 1, nxf, 1, nyf);
    free_dmatrix(rwf, 1, nxf, 1, nyf);
    free_dmatrix(rruf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrwf, 1, nxf/2, 1, nyf/2);
}


void inidefect(double **duc, double **dwc, double **Mo, double **uf_new, double **wf_new,
            double **suf, double **swf, int nxf, int nyf)
{
    double **ruf, **rwf, **ruc, **rwc, **rruf, **rrwf;
    
    ruf = dmatrix(1, nxf, 1, nyf);
    rwf = dmatrix(1, nxf, 1, nyf);
    rruf = dmatrix(1, nxf/2, 1, nyf/2);
    rrwf = dmatrix(1, nxf/2, 1, nyf/2);
    
    
    
    ininonL(ruf, rwf, Mo, uf_new, wf_new, nxf, nyf);
    
 

    mat_sub2(ruf, suf, ruf, rwf, swf, rwf, 1, nxf, 1, nyf);
    

    restrict2(ruf, duc, rwf, dwc, nxf/2, nyf/2);
    
   
    free_dmatrix(ruf, 1, nxf, 1, nyf);
    free_dmatrix(rwf, 1, nxf, 1, nyf);
    free_dmatrix(rruf, 1, nxf/2, 1, nyf/2);
    free_dmatrix(rrwf, 1, nxf/2, 1, nyf/2);
}


void nonL(double **ru, double **rw, double **Mo, double **c_new, double **mu_new, int nxt, int nyt)
{
    extern double dt, Cahn, SS, gam, Pe;
    
    int i, j;
    double **lap_c, **lap_mu, ht2, xright,xleft;

    ht2 = pow((xright-xleft)/(double)nxt,2);
    
    lap_c = dmatrix(1, nxt, 1, nyt);
    lap_mu = dmatrix(1, nxt, 1, nyt);
   
    
    laplace_ch(Mo, c_new, lap_c, nxt, nyt);
    
 
    
    laplace_ch(Mo, mu_new, lap_mu, nxt, nyt);
    

     
    
    ijloopt {
       
       
       ru[i][j] = 3.0*c_new[i][j]/(2.0*dt) - lap_mu[i][j]/Pe;
       
       rw[i][j] = mu_new[i][j] + Cahn*lap_c[i][j]- SS*c_new[i][j];

    }
    
    
    
    free_dmatrix(lap_c, 1, nxt, 1, nyt);
    free_dmatrix(lap_mu, 1, nxt, 1, nyt);
  
}




void ininonL(double **ru, double **rw, double **Mo, double **c_new, double **mu_new, int nxt, int nyt)
{
    extern double dt, Cahn, SS, gam, Pe;
    
    int i, j;
    double **lap_c, **lap_mu, ht2, xright,xleft;

    ht2 = pow((xright-xleft)/(double)nxt,2);
    
    lap_c = dmatrix(1, nxt, 1, nyt);
    lap_mu = dmatrix(1, nxt, 1, nyt);
   
    
    laplace_ch(Mo, c_new, lap_c, nxt, nyt);
    
 
    
    laplace_ch(Mo, mu_new, lap_mu, nxt, nyt);
    

     
    
    ijloopt {
       
       
       ru[i][j] = 1.0*c_new[i][j]/dt - lap_mu[i][j]/Pe;
       
       rw[i][j] = mu_new[i][j] + Cahn*lap_c[i][j]- SS*c_new[i][j];

    }
    
    
    
    free_dmatrix(lap_c, 1, nxt, 1, nyt);
    free_dmatrix(lap_mu, 1, nxt, 1, nyt);
  
}

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uc[i][j] = 0.25*(uf[2*i-1][2*j-1] + uf[2*i-1][2*j] + uf[2*i][2*j-1] + uf[2*i][2*j]);
        vc[i][j] = 0.25*(vf[2*i-1][2*j-1] + vf[2*i-1][2*j] + vf[2*i][2*j-1] + vf[2*i][2*j]);
    }
    
}


void restrict1(double **vf, double **vc, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        vc[i][j] = 0.25*(vf[2*i-1][2*j-1] + vf[2*i-1][2*j] + vf[2*i][2*j-1] + vf[2*i][2*j]);
    }
    
}

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt)
{
    int i, j;
    
    ijloopt {
        uf[2*i-1][2*j-1] = uf[2*i-1][2*j] = uf[2*i][2*j-1] = uf[2*i][2*j] = uc[i][j];
        vf[2*i-1][2*j-1] = vf[2*i-1][2*j] = vf[2*i][2*j-1] = vf[2*i][2*j] = vc[i][j];
    }
    
}

double error(double **c_old, double **c_new, int nxt, int nyt)
{
    double **r, res;
    
    r = dmatrix(1, nxt, 1, nyt);
    
    mat_sub(r, c_new, c_old, 1, nxt, 1, nyt);
    res = mat_max(r, 1, nxt, 1, nyt);
    
    free_dmatrix(r, 1, nxt, 1, nyt);
    
    return res;
}



/*************** util ****************/
double **dmatrix(long nrl, long nrh, long ncl, long nch)
{
    double **m;
    long i, nrow=nrh-nrl+1+NR_END, ncol=nch-ncl+1+NR_END;
    
    m=(double **) malloc((nrow)*sizeof(double*));
    m+=NR_END;
    m-=nrl;
    
    m[nrl]=(double *) malloc((nrow*ncol)*sizeof(double));
    m[nrl]+=NR_END;
    m[nrl]-=ncl;
    
    for (i=nrl+1; i<=nrh; i++) m[i]=m[i-1]+ncol;
    
    return m;
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
{
    free(m[nrl]+ncl-NR_END);
    free(m+nrl-NR_END);
    
    return;
}

void zero_matrix(double **a, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = 0.0;
        }
    }
    
    return;
}

void mat_copy(double **a, double **b, int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
        }
    }
    
    return;
}

void mat_copy2(double **a, double **b, double **a2, double **b2,
               int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j];
            a2[i][j] = b2[i][j];
        }
    }
    
    return;
}

void mat_add(double **a, double **b, double **c,
             int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
        }
    }
    
    return;
}

void mat_add2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int xl, int xr, int yl, int yr)
{
    int i, j;
    
    for (i=xl; i<=xr; i++) {
        for (j=yl; j<=yr; j++) {
            a[i][j] = b[i][j]+c[i][j];
            a2[i][j] = b2[i][j]+c2[i][j];
        }
    }
    
    return;
}

void mat_sub(double **a, double **b, double **c,
             int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
        }
    }
    
    return;
}

void mat_sub2(double **a, double **b, double **c,
              double **a2, double **b2, double **c2,
              int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            a[i][j] = b[i][j]-c[i][j];
            a2[i][j] = b2[i][j]-c2[i][j];
        }
    }
    
    return;
}

double mat_max(double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    double x = 0.0;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++) {
            if (fabs(a[i][j]) > x)
                x = fabs(a[i][j]);
        }
    }
    
    return x;
}


void print_mat(FILE *fptr, double **a, int nrl, int nrh, int ncl, int nch)
{
    int i, j;
    
    for (i=nrl; i<=nrh; i++) {
        for (j=ncl; j<=nch; j++)
            fprintf(fptr, "   %16.14f", a[i][j]);
        
        fprintf(fptr, "\n");
    }
    
    return;
}


void print_data(double **c, double **co, double **ctt, double **cff)
{
    extern char bufferc[100], bufferc0[100], bufferc2[100], bufferc3[100];
    int i, j;
   FILE *fc, *fc0, *fc2, *fc3;
 
    fc = fopen(bufferc,"a");
    fc0 = fopen(bufferc0,"a");
    fc2 = fopen(bufferc2,"a");
    fc3 = fopen(bufferc3,"a");

   iloop {
        jloop {
 		  
           fprintf(fc, "  %16.14f", c[i][j]);
           fprintf(fc0, "  %16.14f", co[i][j]);
           fprintf(fc2, "  %16.14f", ctt[i][j]);
           fprintf(fc3, "  %16.14f", cff[i][j]);
	   }

                   fprintf(fc, "\n");
                   fprintf(fc0,"\n");
                   fprintf(fc2,"\n");
                   fprintf(fc3,"\n");
    }

   
    fclose(fc);
    fclose(fc0);
    fclose(fc2);
    fclose(fc3);

  return;
}



