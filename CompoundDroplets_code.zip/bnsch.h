void initialization(double **c, double **co, double **ctt, double **cff);

void augmenc(double **c, int nxt, int nyt);

void cahn1(double **c_old, double **cc_old, double **Mo, double **H, double **beta, double **c_new);

void source1(double **c_old, double **cc_old, double **H, double **beta, double **src_c, double **src_mu);

void inicahn1(double **c_old, double **Mo, double **H1, double **beta, double **c_new);

void inisource1(double **c_old, double **H, double **beta, double **src_c, double **src_mu);

void laplace_ch(double **Mo, double **a, double **lap_a, int nxt, int nyt);

void vcycle(double **uf_new, double **Mo, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void inivcycle(double **uf_new, double **Mo, double **wf_new, double **su, double **sw, int nxf, int nyf, int ilevel);

void relax(double **c_new, double **Mo, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void inirelax(double **c_new, double **Mo, double **mu_new, double **su, double **sw, int ilevel, int nxt, int nyt);

void defect(double **duc, double **dwc, double **Mo, double **uf_new, double **wf_new,double **suf, double **swf, int nxf, int nyf);

void inidefect(double **duc, double **dwc, double **Mo, double **uf_new, double **wf_new,double **suf, double **swf, int nxf, int nyf);

void nonL(double **ru, double **rw, double **Mo, double **c_new, double **mu_new, int nxt, int nyt);

void ininonL(double **ru, double **rw, double **Mo, double **c_new, double **mu_new, int nxt, int nyt);

void restrict2(double **uf, double **uc, double **vf, double **vc, int nxt, int nyt);

void restrict1(double **vf, double **vc, int nxt, int nyt);

void prolong_ch(double **uc, double **uf, double **vc, double **vf, int nxt, int nyt);

double error(double **c_old, double **c_new, int nxt, int nyt);


